package com.uamre.jsonproject;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.uamre.jsonproject.models.MovieModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    private ListView listView;
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dialog= new ProgressDialog(this);
        dialog.setIndeterminate(true);
        dialog.setCancelable(false);
        dialog.setMessage("Loading please wait..");

        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder()
        .cacheInMemory(true)
                .cacheOnDisk(true)
        .build();
        ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(getApplicationContext())
        .defaultDisplayImageOptions(defaultOptions)
        .build();
        ImageLoader.getInstance().init(config);


        config = new ImageLoaderConfiguration.Builder(this)
                .build();
        ImageLoader.getInstance().init(config);


        listView = (ListView)findViewById(R.id.ivMovies);


    }

    public class JSONTask extends AsyncTask<String,String,List<MovieModel>>{

        @Override
        protected void onPreExecute() {
            dialog.show();
        }

        @Override
        protected List<MovieModel> doInBackground(String... params) {
            HttpURLConnection Connection = null;
            BufferedReader reader = null;
            try {
                URL url = new URL(params[0]);

                Connection = (HttpURLConnection) url.openConnection();
                Connection.connect();

                InputStream stream = Connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                String line = "";
                StringBuffer buffer = new StringBuffer();

                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }
                String finalJSON=buffer.toString();

                JSONObject parentObject=new JSONObject(finalJSON);

                JSONArray parentArray=parentObject.getJSONArray("movies");

                List<MovieModel> movieModelList=new ArrayList<>();

                Gson gson=new Gson();
                for(int i=0;i<parentArray.length();i++){

                    JSONObject finalObject= parentArray.getJSONObject(i);
                    MovieModel movieModel=gson.fromJson(finalObject.toString(),MovieModel.class);
//                    movieModel.setMovie(finalObject.getString("movie"));
//                    movieModel.setYear(finalObject.getInt("year"));
//                    movieModel.setRating((float) finalObject.getDouble("rating"));
//                    movieModel.setDirector(finalObject.getString("director"));
//                    movieModel.setDuration(finalObject.getString("duration"));
//                    movieModel.setTagline((finalObject.getString("tagline")));
//                    movieModel.setImage(finalObject.getString("image"));
//                    movieModel.setStory(finalObject.getString("story"));
//
//                    List<MovieModel.Cast> castList=new ArrayList<>();
//                    for (int j=0;j<finalObject.getJSONArray("cast").length();j++){
//                        MovieModel.Cast cast=new MovieModel.Cast();
//                        cast.setName(finalObject.getJSONArray("cast").getJSONObject(j).getString("name"));
//                        castList.add(cast);
//                    }
//                    movieModel.setCastList(castList);
//                    //adding the final object in the list
                    movieModelList.add(movieModel);
                }
                return movieModelList;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                if (Connection != null) {
                    Connection.disconnect();
                }

                try {
                    if (reader != null) {
                        reader.close();
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(List<MovieModel> result) {
            super.onPostExecute(result);

            dialog.dismiss();
            MovieAdapter adapter=new MovieAdapter(getApplicationContext(), R.layout.raw,result);
            listView.setAdapter(adapter);
            //TODO need to set data to the list
        }
    }

    public class MovieAdapter extends ArrayAdapter{

        public List<MovieModel> movieModelList;
        private int resource;
        private LayoutInflater inflater;

        public MovieAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List objects) {
            super(context, resource, objects);
            movieModelList=objects;
            this.resource=resource;
            inflater=(LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE);

        }

        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

            ViewHolder holder= null;
            if(convertView==null){
                holder=new ViewHolder();
                convertView= inflater.inflate(resource,null);
                holder.ivMovieIcon=(ImageView)convertView.findViewById(R.id.ivIcon);
                holder.tvMovie=(TextView)convertView.findViewById(R.id.tvMovie);
                holder.tvTagline=(TextView)convertView.findViewById(R.id.tvTagline);
                holder.tvYear=(TextView)convertView.findViewById(R.id.tvYear);
                holder.tvDuration=(TextView)convertView.findViewById(R.id.tvDuration);
                holder.tvDirector=(TextView)convertView.findViewById(R.id.tvDirector);
                holder.rbMovie=(RatingBar) convertView.findViewById(R.id.rbMovie);
                holder.tvCast=(TextView)convertView.findViewById(R.id.tvCast);
                holder.tvStory=(TextView)convertView.findViewById(R.id.tvStory);
                convertView.setTag(holder);
            }else{
                holder=(ViewHolder)convertView.getTag();
            }





            final ProgressBar progressBar=(ProgressBar)convertView.findViewById(R.id.progressBar2);

            ImageLoader.getInstance().displayImage(movieModelList.get(position).getImage(), holder.ivMovieIcon, new ImageLoadingListener() {
                @Override
                public void onLoadingStarted(String imageUri, View view) {
                    progressBar.setVisibility(view.VISIBLE);
                }

                @Override
                public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
                    progressBar.setVisibility(View.GONE);
                }

                @Override
                public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
                    progressBar.setVisibility(View.GONE);
                }

                @Override
                public void onLoadingCancelled(String imageUri, View view) {
                    progressBar.setVisibility(View.GONE);
                }
            });

            holder.tvMovie.setText(movieModelList.get(position).getMovie());
            holder.tvTagline.setText(movieModelList.get(position).getTagline());
            holder.tvYear.setText("Year: "+ movieModelList.get(position).getYear());
            holder.tvDuration.setText("Duration: "+ movieModelList.get(position).getDuration());
            holder.tvDirector.setText("Director: "+movieModelList.get(position).getDirector());

            holder.rbMovie.setRating(movieModelList.get(position).getRating()/2);


            StringBuffer stringBuffer= new StringBuffer();
            for(MovieModel.Cast cast: movieModelList.get(position).getCastList()){
                stringBuffer.append(cast.getName() + ", ");
            }

            holder.tvCast.setText("Casr: "+ stringBuffer);
            holder.tvStory.setText(movieModelList.get(position).getStory());

            return convertView;
        }
        class ViewHolder{
            private ImageView ivMovieIcon;
            private TextView tvMovie;
            private TextView tvTagline;
            private TextView tvYear;
            private TextView tvDuration;
            private TextView tvDirector;
            private RatingBar rbMovie;
            private TextView tvCast;
            private TextView tvStory;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_refresh) {
            new JSONTask().execute("https://jsonparsingdemo-cec5b.firebaseapp.com/jsonData/moviesData.txt");
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


}
